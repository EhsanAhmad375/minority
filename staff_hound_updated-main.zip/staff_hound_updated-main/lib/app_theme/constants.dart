import 'dart:ui';

const primaryColor = Color(0xff283172);
const secondaryColor = Color(0xff5BC0EB);
const gradient1 = Color(0xff254C77);
const borderColor = Color(0xffF7931E);
const containerColor = Color(0xffF5F5F5);
const lineColor = Color(0xff9A9A9A);
const greyColor = Color(0xffCACACA);
