import 'package:flutter/material.dart';
// ignore_for_file: public_member_api_docs, sort_constructors_first

class HomeJobModel {
    String icon;
    String? title;
  HomeJobModel({
    required this.icon,
    this.title,
  });
    
}
