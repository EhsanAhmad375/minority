class FlagModel {
  String flagUrl;
  String countryName;
  FlagModel({required this.countryName, required this.flagUrl});
}
