import 'package:flutter/material.dart';
// ignore_for_file: public_member_api_docs, sort_constructors_first

class FilterModel {
  Color? color;
  String? title;
  String? loc;
  String? duration;
  String? day;
  String? range;
  FilterModel({
    this.color,
    this.title,
    this.loc,
    this.duration,
    this.day,
    this.range,
  });

}
