package com.example.staff_hound

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
