package com.example.task_for_developers

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
