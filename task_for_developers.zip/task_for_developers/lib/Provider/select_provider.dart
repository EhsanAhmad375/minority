import 'dart:ffi';
import 'package:flutter/foundation.dart';

class SelectProvider with ChangeNotifier {
//   bool _isExpressed = false;
//   bool get isExpressed => _isExpressed;
  
//   bool _isStandard = false;
//   bool get isStandard => _isStandard;

// String _selectedValueCity = '';

//   String get selectedValueCity => _selectedValueCity;

//   void selectedValueCitys(String value) {
//     _selectedValueCity = value;
//     notifyListeners();
//   }
// String _selectedValueOfArea = 'dfsd';

//   String get selectedValueOfArea => _selectedValueOfArea;

//   void selectedValuesOfArea(String value) {
//     _selectedValueOfArea = value;
//     notifyListeners();
//   }
//   void myvalue(){
//     print(_selectedValueOfArea.toString());
//   }

//   void Expressed() {
//     _isExpressed = true;
//     _isStandard = false;
//     notifyListeners();
//   }

//   void Standard() {
//     _isExpressed = false;
//     _isStandard = true;
//     notifyListeners();
//   }
}