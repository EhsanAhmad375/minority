// ignore_for_file: public_member_api_docs, sort_constructors_first
class JobTypeModel {
  String? salaryRange;
  String? min_max;
  String? JobType;
  bool isSelected;
  JobTypeModel({
    this.salaryRange,
    this.min_max,
    this.JobType,
     this.isSelected=false
  });
}
