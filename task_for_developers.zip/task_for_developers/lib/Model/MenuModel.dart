import 'package:flutter/material.dart';
class MenuModel {
  String? title;
  IconData? icons;
  MenuModel({
    this.title,
    this.icons,
  });

}
