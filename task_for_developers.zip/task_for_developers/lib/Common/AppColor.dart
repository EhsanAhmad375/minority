import 'package:flutter/material.dart';

class AppColors{
  static Color darkPurple=Color(0xff691DB3);
  static Color styBlue=Color.fromARGB(255, 226, 236, 245);
  static Color green=Color(0xff31FE9C);
  static Color white=Colors.white;
  static Color gray=Colors.grey.shade100;
  
}