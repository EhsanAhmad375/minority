import 'package:flutter/material.dart';

class RouteName{
  static const String BottomNavBarCustom='bottomNavBarCustom';
  static const String home='home';
  static const String filterd='Filtered';
  static const String jobDetailDescription='jobDetailDescription';
  static const String jobDetailDuties='jobDetailDuties';
  static const String jobDetailsSkillsRequred='jobDetailsSkillsRequred';
  static const String profile='profile';
  
}